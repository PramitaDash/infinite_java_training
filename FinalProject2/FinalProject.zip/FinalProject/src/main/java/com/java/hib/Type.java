package com.java.hib;

public enum Type {
	
	DOCTOR, OWNER
	
}
